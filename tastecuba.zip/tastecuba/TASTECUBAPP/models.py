from django.db import models


# Create your models here.
class applicants(models.Model):
    Username = models.CharField(max_length=50)
    Password = models.CharField(max_length=50)
    FirstName = models.CharField(max_length=50)
    LastName = models.CharField(max_length=50)
    Gender = models.CharField(max_length=6)
    DateOfBirth = models.DateTimeField()
    Address = models.CharField(max_length=100)
    City = models.CharField(max_length=50)
    State = models.CharField(max_length=50)
    ZipCode = models.IntegerField()
    Email = models.CharField(max_length=50)
    PhoneNumber = models.IntegerField()
    CountryOfOrigin = models.CharField(max_length=50)
