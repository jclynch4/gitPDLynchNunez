from django.db import connections
from django.db import models


class Rooms(models.Model):
    RoomNumber = models.CharField(max_lengh=11)
    Floor = models.CharField(max_lengh=11)
    NoOfBeds = models.CharField(max_lengh=11)
    CostPerNight = models.CharField(max_lengh=11)
    RoomService = models.CharField(max_lengh=11)

    class Meta:
        db_table = "rooms"
